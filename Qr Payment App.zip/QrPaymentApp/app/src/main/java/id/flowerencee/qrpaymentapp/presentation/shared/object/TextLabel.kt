package id.flowerencee.qrpaymentapp.presentation.shared.`object`

data class TextLabel(
    var order: Int,
    var label: String,
    var value: String
)
