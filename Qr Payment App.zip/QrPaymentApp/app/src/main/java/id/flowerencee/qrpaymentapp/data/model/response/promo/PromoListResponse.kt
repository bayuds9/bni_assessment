package id.flowerencee.qrpaymentapp.data.model.response.promo

class PromoListResponse : ArrayList<PromoItem>()